package bloghug;

import org.jsoup.Jsoup;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        System.out.println("  ____  _      ____   _____ _                 \n" +
                " |  _ \\| |    / __ \\ / ____| |                \n" +
                " | |_) | |   | |  | | |  __| |__  _   _  __ _ \n" +
                " |  _ <| |   | |  | | | |_ | '_ \\| | | |/ _` |\n" +
                " | |_) | |___| |__| | |__| | | | | |_| | (_| |\n" +
                " |____/|______\\____/ \\_____|_| |_|\\__,_|\\__, |\n" +
                " Technical Assessment for Caplin Systems __/ |\n" +
                " - made by Michal B. Zietek             |___/ ");


        int allWords;
        int all_S_Words;
        double percentage;

        try {
            String webPage = "https://blog.caplin.com/";
            URL url = new URL(webPage);
            URLConnection urlConnection = url.openConnection();
            InputStream is = urlConnection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);

            int numCharsRead;
            char[] charArray = new char[1024];
            StringBuilder sb = new StringBuilder();
            while ((numCharsRead = isr.read(charArray)) > 0) {
                sb.append(charArray, 0, numCharsRead);
            }

            String plainText = Jsoup.parse(sb.toString()).text();
            plainText = plainText.replaceAll("[^\\p{IsAlphabetic}^\\p{IsDigit}]", ",");
            plainText = plainText.replaceAll(",,,", ",").replaceAll(",,", ","); // cleaning as trim() did not work

            List<String> myList = new ArrayList<>(Arrays.asList(plainText.split(",")));

            Collections.sort(myList);
            myList.remove(0); // removing one empty character that somehow got through cleaning

            allWords = myList.size();

            List<String> listClone = new ArrayList<>();
            for (String string : myList) {
                if (string.matches("(?i)(s).*")) {
                    listClone.add(string);
                }
            }

            all_S_Words = listClone.size();

            //count all words beginning with the letter 's'
            System.out.println("\nWebsite has: \n" + all_S_Words + " words beginning with the letter 's'.\n");

            //print out how many words begin with 's'
            System.out.println("Printing all found words: \n" + listClone);

            //print out what percentage of all the words in the file begin with the letter 's'
            percentage = (float) (all_S_Words * 100) / allWords;
            System.out.println("\nPercentage of all the words in the file that begin with the letter 's' is: \n" + percentage + "%");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
